import { Content } from '@angular/compiler/src/render3/r3_ast';
import { Component, OnInit } from '@angular/core';
import { Todo } from './../../models/Todo'; 

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  //Array of Todo objects (under models folder)
  todos?:Todo[];

  inputTodo:string = "";
  constructor() { }

  ngOnInit(): void {
      //initializing todos array
      this.todos = [
        {
          content: 'First todo',
          completed: false
        },
        {
          content: 'Second todo',
          completed: false
        }
      ]
      //export to app component

      
  }
  //method for deletion of item within list
    toggleDone (id: number): void {
        //loop through all todos indexs
        this.todos?.map((v, i) => {
            //if current index == given id
            if (i == id) {
              //mark the index
              v.completed = !v.completed;
            }
            return v;
        })
    }

  //Deleting a todo from the list
    deleteTodo (id: number) {
      //given the id to be deleted, fetch it from the list
      this.todos = this.todos?.filter((v, i) => i != id);
    }

  //Adding a todo to the list
    addTodo () {
      this.todos?.push({
        content: this.inputTodo,
        completed: false
      });

      //reset value of inputTodo
      this.inputTodo = "";
    }
}
